const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient();

const create = (domainName, stage) => {
    const endpoint = domainName + '/' + stage;
    return new AWS.ApiGatewayManagementApi({
        apiVersion: '2018-11-29',
        endpoint,
    });
};

const getConnections = () => ddb.scan({ TableName: 'WebsocketUsers' }).promise();

const send = ({ domainName, stage, connectionID, message }) => {
    const ws = create(domainName, stage);
    getConnections().then((data) => {
        data.Items.forEach(function (connection) {
            const postParams = {
                Data: message,
                ConnectionId: connectionID,
            };
            ws.postToConnection(postParams).promise();
        });
    }); return {}
};

module.exports = {
    send,
};
