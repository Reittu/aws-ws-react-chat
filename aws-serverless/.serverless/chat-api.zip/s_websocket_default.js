var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'reittu',
applicationName: 'my-first-app',
appUid: 'H0xwVqDsMQMMlCxwhS',
orgUid: 'HLxkwNq5lbf6SnK1Mc',
deploymentUid: '7aae9c6f-53d3-43af-88f3-b2a5b96dbb56',
serviceName: 'chat-api',
shouldLogMeta: true,
disableAwsSpans: false,
disableHttpSpans: false,
stageName: 'dev',
pluginVersion: '3.5.0',
disableFrameworksInstrumentation: false})
const handlerWrapperArgs = { functionName: 'chat-api-dev-websocket-default', timeout: 6}
try {
  const userHandler = require('./lambdas/websockets/default.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
